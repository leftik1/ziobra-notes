from core.app_screen import AppScreen
from kivy.uix.textinput import TextInput
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.scrollview import ScrollView
from kivy.uix.label import Label
from kivy.uix.gridlayout import GridLayout
from kivy.graphics import Color, RoundedRectangle

import json
import os
from datetime import datetime

FILE = "notes.json"


class NotesScreen(AppScreen):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.notes = []
        self.current_note = None

        # root
        self.root_layout = BoxLayout(orientation="vertical")
        self.add_widget(self.root_layout)

        # контейнер для динамической смены экранов
        self.container = BoxLayout()
        self.root_layout.add_widget(self.container)

        self.build_list_ui()

    # =========================
    # DATA
    # =========================

    def load_notes(self):
        if not os.path.exists(FILE):
            return []
        with open(FILE, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_notes(self):
        with open(FILE, "w", encoding="utf-8") as f:
            json.dump(self.notes, f, indent=2, ensure_ascii=False)

    def create_note(self):
        return {
            "id": str(datetime.now().timestamp()),
            "title": "Новая заметка",
            "content": "",
            "created": str(datetime.now()),
        }

    # =========================
    # LIST UI
    # =========================

    def build_list_ui(self):
        self.container.clear_widgets()

        root = BoxLayout(orientation="vertical", padding=10, spacing=10)

        # верхняя панель
        top = BoxLayout(size_hint=(1, 0.1))

        back = Button(text="Back")
        back.bind(on_press=self.go_back)

        add = Button(text="New Note")
        add.bind(on_press=self.add_note)

        top.add_widget(back)
        top.add_widget(add)

        root.add_widget(top)

        # список
        scroll = ScrollView()

        self.grid = GridLayout(cols=1, spacing=10, size_hint_y=None)
        self.grid.bind(minimum_height=self.grid.setter('height'))

        scroll.add_widget(self.grid)
        root.add_widget(scroll)

        self.container.add_widget(root)

        self.refresh_notes()

    def refresh_notes(self):
        self.notes = self.load_notes()

        self.grid.clear_widgets()

        if not self.notes:
            self.grid.add_widget(Label(text="Empty... create your first note!"))
            return

        # новые сверху
        self.notes = list(reversed(self.notes))

        for note in self.notes:
            self.grid.add_widget(self.create_note_card(note))

    def create_note_card(self, note):
        card = Button(
            text=f"{note['title']}\n{note['content'][:50]}",
            size_hint_y=None,
            height=100,
        )

        card.bind(on_press=lambda x: self.open_note(note))
        return card

    # =========================
    # EDITOR UI
    # =========================

    def build_editor_ui(self, note):
        self.container.clear_widgets()

        root = BoxLayout(orientation="vertical", spacing=5, padding=5)

        # верх
        top = BoxLayout(size_hint=(1, 0.1))

        back = Button(text="Back")
        save = Button(text="Save")
        delete = Button(text="Delete")

        back.bind(on_press=lambda x: self.build_list_ui())
        save.bind(on_press=lambda x: self.save_current_note())
        delete.bind(on_press=lambda x: self.delete_note())

        top.add_widget(back)
        top.add_widget(save)
        top.add_widget(delete)

        # заголовок
        self.title_input = TextInput(
            text=note["title"],
            size_hint=(1, 0.1),
            multiline=False
        )

        # текст
        self.content_input = TextInput(
            text=note["content"],
            hint_text="Write your note here...",
            multiline=True
        )

        root.add_widget(top)
        root.add_widget(self.title_input)
        root.add_widget(self.content_input)

        self.container.add_widget(root)

    # =========================
    # ACTIONS
    # =========================

    def add_note(self, instance):
        note = self.create_note()
        self.current_note = note
        self.build_editor_ui(note)

    def open_note(self, note):
        self.current_note = note
        self.build_editor_ui(note)

    def save_current_note(self):
        if not self.current_note:
            return

        self.current_note["title"] = self.title_input.text
        self.current_note["content"] = self.content_input.text

        # если новой ещё нет в списке
        if self.current_note not in self.notes:
            self.notes.append(self.current_note)

        self.save_notes()
        self.build_list_ui()

    def delete_note(self):
        if self.current_note in self.notes:
            self.notes.remove(self.current_note)
            self.save_notes()

        self.build_list_ui()

    def go_back(self, instance):
        if self.router:
            self.router.go("home")

    # =========================
    # LIFECYCLE
    # =========================

    def on_resume(self):
        self.refresh_notes()