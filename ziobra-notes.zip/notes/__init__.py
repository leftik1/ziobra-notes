# notes/__init__.py

from .notes import NotesScreen